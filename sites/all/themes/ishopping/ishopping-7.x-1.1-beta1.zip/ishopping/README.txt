---------------------------------------
----------- About iShopping -----------
---------------------------------------

iShopping provides a Ubercart-based solution to build small online shopping
websites.
- Theme Version 7.x-1.0-beta
- Released on: 2012-09-06
- Compatible with Drupal 7.x, Nucleus basetheme
- Copyright (C) 2012-2012 www.WeebPal.com. All Rights Reserved.
- @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
- Author: WeebPal
- Website: http://www.weebpal.com
- Twitter: http://twitter.com/weebpal
- Facebook: http://www.facebook.com/weebpal
- Pinterest: http://www.pinterest.com/weebpal
