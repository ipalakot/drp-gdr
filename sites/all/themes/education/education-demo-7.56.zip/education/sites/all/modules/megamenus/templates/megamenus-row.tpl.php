<div <?php print $attributes;?> class="row-fluid <?php print $classes;?> clearfix">
  <?php print $columns;?>
</div>
