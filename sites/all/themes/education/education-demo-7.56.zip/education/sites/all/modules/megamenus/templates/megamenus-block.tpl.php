<?php if($content) :?>
<div <?php print $attributes;?> class="<?php print $classes;?>">
  <?php print $content ?>
</div>
<?php endif;?>
